package com.example.rentview.ui.adapters


import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.rentview.R
import com.example.rentview.data.PropertyItem
import com.example.rentview.ui.Formatters
import com.example.rentview.ui.ImageLoader
// Shows the list of approved properties. RecyclerView only creates enough
// card views to fill the screen and reuses them while the user scrolls.
class PropertyAdapter(
    private val onPropertyClicked: (PropertyItem) -> Unit
) : ListAdapter<PropertyItem, PropertyAdapter.PropertyViewHolder>(DIFF) {

    class PropertyViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val photo: ImageView = view.findViewById(R.id.ivPropertyPhoto)
        val title: TextView = view.findViewById(R.id.tvPropertyTitle)
        val location: TextView = view.findViewById(R.id.tvPropertyLocation)
        val bedrooms: TextView = view.findViewById(R.id.tvPropertyBedrooms)
        val rent: TextView = view.findViewById(R.id.tvPropertyRent)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PropertyViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_property, parent, false)
        return PropertyViewHolder(view)
    }

    override fun onBindViewHolder(holder: PropertyViewHolder, position: Int) {
        val property = getItem(position)

        holder.title.text = property.title
        holder.location.text = property.location
        holder.bedrooms.text = Formatters.bedrooms(property.bedrooms)
        holder.rent.text = Formatters.rent(property.rent)

        // Show the first photo as the card's picture, if the owner uploaded any.
        val firstPhoto = property.photoUris.firstOrNull()
        if (firstPhoto == null) {
            holder.photo.visibility = View.GONE
            holder.photo.tag = null
        } else {
            holder.photo.visibility = View.VISIBLE
            ImageLoader.load(holder.photo, firstPhoto, 600)
        }

        holder.itemView.setOnClickListener { onPropertyClicked(property) }
    }

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<PropertyItem>() {
            override fun areItemsTheSame(old: PropertyItem, new: PropertyItem) =
                old.id == new.id

            override fun areContentsTheSame(old: PropertyItem, new: PropertyItem) =
                old == new
        }
    }
}
