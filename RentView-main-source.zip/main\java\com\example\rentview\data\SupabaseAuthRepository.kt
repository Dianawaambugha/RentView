package com.example.rentview.data

import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.auth.providers.builtin.Email
import io.github.jan.supabase.postgrest.from
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put

class SupabaseAuthRepository {

    private val client = SupabaseClient.client

    suspend fun register(
        fullName: String,
        email: String,
        phone: String,
        password: String,
        role: String
    ) {
        require(role == "TENANT" || role == "PROPERTY_OWNER") {
            "Invalid registration role"
        }

        client.auth.signUpWith(Email) {
            this.email = email.trim()
            this.password = password

            data = buildJsonObject {
                put("full_name", fullName.trim())
                put("phone", phone.trim())
                put("role", role)
            }
        }
    }

    suspend fun login(
        email: String,
        password: String,
        database: RentViewDatabase
    ): UserEntity {

        client.auth.signInWith(Email) {
            this.email = email.trim()
            this.password = password
        }

        val supabaseUserId = client.auth.currentUserOrNull()?.id
            ?: throw Exception("Unable to retrieve authenticated user.")

        val profiles = client.from("profiles")
            .select()
            .decodeList<JsonObject>()
        val profile = profiles.firstOrNull { profile ->
            profile["id"]?.toString()?.replace("\"", "") == supabaseUserId
        } ?: throw Exception("Your user profile could not be found.")

        fun getValue(key: String): String? {
            return profile[key]?.jsonPrimitive?.toString()
                ?.removeSurrounding("\"")
        }

        val fullName = getValue("full_name")
            ?: throw Exception("Your profile is missing your full name.")

        val profileEmail = getValue("email") ?: email.trim()
        val phone = getValue("phone") ?: ""

        val cloudRole = getValue("role")
            ?: throw Exception("Your account has no assigned role.")

        val approvalStatus = getValue("approval_status") ?: "PENDING"

        val localRole = when (cloudRole) {
            "TENANT" -> "Tenant"
            "PROPERTY_OWNER" -> "Property Owner"
            "ADMIN" -> "ADMIN"
            else -> throw Exception("Your account has an invalid role.")
        }

        val userDao = database.userDao()

        val existingUser =
            userDao.getBySupabaseUserId(supabaseUserId)
                ?: userDao.getByEmail(profileEmail)

        val localUser = if (existingUser != null) {

            val updatedUser = existingUser.copy(
                fullName = fullName,
                email = profileEmail,
                phone = phone,
                passwordHash = "",
                role = localRole,
                approvalStatus = approvalStatus,
                supabaseUserId = supabaseUserId
            )

            userDao.update(updatedUser)
            updatedUser

        } else {

            val newUser = UserEntity(
                fullName = fullName,
                email = profileEmail,
                phone = phone,
                passwordHash = "",
                role = localRole,
                approvalStatus = approvalStatus,
                supabaseUserId = supabaseUserId
            )

            val localId = userDao.insert(newUser)

            userDao.getById(localId)
                ?: throw Exception("Unable to save your local user profile.")
        }

        return localUser
    }

    suspend fun logout() {
        client.auth.signOut()
    }
}