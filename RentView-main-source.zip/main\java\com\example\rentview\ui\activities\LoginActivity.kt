package com.example.rentview.ui.activities

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.rentview.R
import com.example.rentview.data.RentViewDatabase
import com.example.rentview.data.SupabaseAuthRepository
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {

    companion object {
        const val USER_ID = "USER_ID"
        const val USER_NAME = "USER_NAME"
        const val USER_ROLE = "USER_ROLE"
        const val APPROVAL_STATUS = "APPROVAL_STATUS"
        const val SUPABASE_USER_ID = "SUPABASE_USER_ID"
    }

    private val authRepository by lazy {
        SupabaseAuthRepository()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val email = findViewById<EditText>(R.id.etLoginEmail)
        val password = findViewById<EditText>(R.id.etLoginPassword)
        val loginButton = findViewById<Button>(R.id.btnLogin)
        val registerLink = findViewById<TextView>(R.id.tvGoToRegister)

        registerLink.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }

        loginButton.setOnClickListener {
            val emailValue = email.text.toString().trim()
            val passwordValue = password.text.toString()

            if (emailValue.isEmpty()) {
                email.error = "Enter your email"
                return@setOnClickListener
            }

            if (passwordValue.isEmpty()) {
                password.error = "Enter your password"
                return@setOnClickListener
            }

            loginButton.isEnabled = false

            lifecycleScope.launch {
                try {
                    val database = RentViewDatabase.getInstance(this@LoginActivity)

                    val user = authRepository.login(
                        emailValue,
                        passwordValue,
                        database
                    )

                    when (user.role) {
                        "Tenant" -> {
                            if (user.approvalStatus != "APPROVED") {
                                authRepository.logout()
                                Toast.makeText(
                                    this@LoginActivity,
                                    "Your tenant account is not approved.",
                                    Toast.LENGTH_LONG
                                ).show()
                                return@launch
                            }
                        }

                        "Property Owner" -> {
                            when (user.approvalStatus) {
                                "PENDING" -> {
                                    authRepository.logout()
                                    Toast.makeText(
                                        this@LoginActivity,
                                        "Your account is awaiting administrator approval.",
                                        Toast.LENGTH_LONG
                                    ).show()
                                    return@launch
                                }

                                "REJECTED" -> {
                                    authRepository.logout()
                                    Toast.makeText(
                                        this@LoginActivity,
                                        "Your property owner application was rejected.",
                                        Toast.LENGTH_LONG
                                    ).show()
                                    return@launch
                                }

                                "APPROVED" -> Unit

                                else -> {
                                    authRepository.logout()
                                    Toast.makeText(
                                        this@LoginActivity,
                                        "Your account has an invalid approval status.",
                                        Toast.LENGTH_LONG
                                    ).show()
                                    return@launch
                                }
                            }
                        }

                        else -> {
                            authRepository.logout()
                            Toast.makeText(
                                this@LoginActivity,
                                "Please use the appropriate login screen for your account.",
                                Toast.LENGTH_LONG
                            ).show()
                            return@launch
                        }
                    }

                    val intent = Intent(this@LoginActivity, HomeActivity::class.java).apply {
                        putExtra(USER_ID, user.id)
                        putExtra(USER_NAME, user.fullName)
                        putExtra(USER_ROLE, user.role)
                        putExtra(APPROVAL_STATUS, user.approvalStatus)
                        putExtra(SUPABASE_USER_ID, user.supabaseUserId)
                    }

                    startActivity(intent)
                    finish()

                } catch (exception: Exception) {
                    Toast.makeText(
                        this@LoginActivity,
                        exception.message ?: "Login failed. Please try again.",
                        Toast.LENGTH_LONG
                    ).show()
                } finally {
                    loginButton.isEnabled = true
                }
            }
        }
    }
}