package com.example.rentview.ui.activities

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.rentview.R
import com.example.rentview.data.RentViewDatabase
import com.example.rentview.data.SupabaseAuthRepository
import kotlinx.coroutines.launch

class AdminLoginActivity : AppCompatActivity() {

    private val authRepository by lazy {
        SupabaseAuthRepository()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_login)

        val email = findViewById<EditText>(R.id.etAdminEmail)
        val password = findViewById<EditText>(R.id.etAdminPassword)
        val loginButton = findViewById<Button>(R.id.btnAdminLogin)

        loginButton.setOnClickListener {
            val emailValue = email.text.toString().trim()
            val passwordValue = password.text.toString()

            if (emailValue.isEmpty()) {
                email.error = "Enter administrator email"
                return@setOnClickListener
            }

            if (passwordValue.isEmpty()) {
                password.error = "Enter administrator password"
                return@setOnClickListener
            }

            loginButton.isEnabled = false

            lifecycleScope.launch {
                try {
                    val database = RentViewDatabase.getInstance(this@AdminLoginActivity)

                    val user = authRepository.login(
                        emailValue,
                        passwordValue,
                        database
                    )

                    if (user.role != "ADMIN" ||
                        user.approvalStatus != "APPROVED"
                    ) {
                        authRepository.logout()

                        Toast.makeText(
                            this@AdminLoginActivity,
                            "This account does not have administrator access.",
                            Toast.LENGTH_LONG
                        ).show()

                        return@launch
                    }

                    Toast.makeText(
                        this@AdminLoginActivity,
                        "Administrator login successful",
                        Toast.LENGTH_SHORT
                    ).show()

                    startActivity(
                        Intent(
                            this@AdminLoginActivity,
                            AdminDashboardActivity::class.java
                        )
                    )

                    finish()

                } catch (exception: Exception) {
                    Toast.makeText(
                        this@AdminLoginActivity,
                        exception.message ?: "Administrator login failed.",
                        Toast.LENGTH_LONG
                    ).show()
                } finally {
                    loginButton.isEnabled = true
                }
            }
        }
    }
}